#ifndef MOSCLIB_HAS_MISC
#define MOSCLIB_HAS_MISC
int os_get_api_version();
void os_pause(int time);
void os_fatal_error(char *error);
#endif


