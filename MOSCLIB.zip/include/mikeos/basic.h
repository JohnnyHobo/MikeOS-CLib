#ifndef MOSCLIB_HAS_BASIC
#define MOSCLIB_HAS_BASIC
void os_run_basic(void *code, int size, char *parameters);
#endif
