#ifndef MOSCLIB_HAS_MEMORY
#define MOSCLIB_HAS_MEMORY
void *malloc(int size);
void free(void *blk);
#endif

