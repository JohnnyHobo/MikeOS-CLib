#ifndef MOSCLIB_HAS_STRING
#define MOSCLIB_HAS_STRING

int strlen(char *str);
char *strcpy(char *destination, char *source);
char *strcat(char *destination, char *source);

#endif