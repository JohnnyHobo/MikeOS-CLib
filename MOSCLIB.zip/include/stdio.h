#ifndef MOSCLIB_HAS_STDIO
#define MOSCLIB_HAS_STDIO
#include "print.h"
#endif
