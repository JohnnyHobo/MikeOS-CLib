#ifndef MOSCLIB_HAS_PRINT
#define MOSCLIB_HAS_PRINT
int printf(char *fmt, ...);
int putchar(int character);
int puts(char *str);
char *gets(char *str);
#endif
